package com.example.creamlunarweather.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CreamBackground = Color(0xFFF7F3E8)
val CreamCard = Color(0xFFFAF7F0)
val CreamSoftPill = Color(0xFFEDE7D6)
val InkBlack = Color(0xFF141414)
val InkMuted = Color(0xFF5A564E)
val DarkPillBg = Color(0xFF181818)
val DarkPillText = Color(0xFFF7F3E8)
val TodayRed = Color(0xFFD92D20)
val BorderCream = Color(0xFFE3DCC9)

private val CreamColorScheme = lightColorScheme(
    primary = InkBlack,
    background = CreamBackground,
    surface = CreamCard,
    onPrimary = CreamBackground,
    onBackground = InkBlack,
    onSurface = InkBlack
)

@Composable
fun CreamLunarWeatherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CreamColorScheme,
        content = content
    )
}
