package com.example.creamlunarweather

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Grain
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Thunderstorm
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.creamlunarweather.ui.theme.BorderCream
import com.example.creamlunarweather.ui.theme.CreamBackground
import com.example.creamlunarweather.ui.theme.CreamCard
import com.example.creamlunarweather.ui.theme.CreamLunarWeatherTheme
import com.example.creamlunarweather.ui.theme.CreamSoftPill
import com.example.creamlunarweather.ui.theme.DarkPillBg
import com.example.creamlunarweather.ui.theme.DarkPillText
import com.example.creamlunarweather.ui.theme.InkBlack
import com.example.creamlunarweather.ui.theme.InkMuted
import com.example.creamlunarweather.ui.theme.TodayRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CreamLunarWeatherTheme {
                HomeDashboardScreen(
                    latitude = 20.8449,
                    longitude = 106.6881
                )
            }
        }
    }
}

@Composable
fun HomeDashboardScreen(
    latitude: Double,
    longitude: Double
) {
    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    var currentTime by remember { mutableStateOf(LocalTime.now()) }
    var currentDate by remember { mutableStateOf(LocalDate.now()) }
    var weatherState by remember { mutableStateOf(WeatherUiState(isLoading = true)) }

    fun refreshWeather() {
        coroutineScope.launch {
            weatherState = weatherState.copy(isLoading = true, errorMessage = null)
            WeatherApi.fetchWeather(latitude, longitude)
                .onSuccess { weatherState = it }
                .onFailure { err ->
                    weatherState = weatherState.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Không tải được dữ liệu thời tiết"
                    )
                }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = LocalTime.now()
            currentDate = LocalDate.now()
            delay(1000L)
        }
    }

    LaunchedEffect(Unit) {
        refreshWeather()
        while (true) {
            delay(30 * 60 * 1000L)
            refreshWeather()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                currentTime = LocalTime.now()
                currentDate = LocalDate.now()
                refreshWeather()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val greeting = getGreetingByHour(currentTime.hour)
    val timeText = currentTime.format(DateTimeFormatter.ofPattern("HH:mm"))
    val fullDateText = formatVietnameseFullDate(currentDate)
    val lunarInfo = remember(currentDate) { LunarCalendar.getLunarDate(currentDate) }
    val weekDays = remember(currentDate) { LunarCalendar.getWeekStrip(currentDate) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(CreamCard)
                        .border(1.dp, BorderCream, RoundedCornerShape(28.dp))
                        .padding(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = greeting,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkBlack
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(DarkPillBg)
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = lunarInfo.pillLabel(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkPillText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = timeText,
                        fontSize = 68.sp,
                        lineHeight = 72.sp,
                        fontWeight = FontWeight.Black,
                        color = InkBlack,
                        letterSpacing = (-2).sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = fullDateText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = InkBlack
                    )
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(CreamCard)
                        .border(1.dp, BorderCream, RoundedCornerShape(28.dp))
                        .padding(horizontal = 12.dp, vertical = 18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        weekDays.forEach { item ->
                            val dayBg = if (item.isToday) TodayRed else CreamSoftPill
                            val dayTextColor = if (item.isToday) CreamCard else InkBlack
                            val weekdayColor = if (item.isToday) TodayRed else InkMuted

                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = item.shortWeekday,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = weekdayColor
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(dayBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = item.solarDay.toString(),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = dayTextColor,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = item.lunarShort,
                                    fontSize = 11.sp,
                                    fontWeight = if (item.isToday) FontWeight.Bold else FontWeight.SemiBold,
                                    color = if (item.isToday) TodayRed else InkMuted
                                )
                            }
                        }
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(CreamCard)
                        .border(1.dp, BorderCream, RoundedCornerShape(28.dp))
                        .padding(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Thời tiết hôm nay",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkBlack
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(CreamSoftPill)
                                .clickable { refreshWeather() }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Refresh,
                                    contentDescription = "Cập nhật",
                                    tint = InkBlack,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Cập nhật",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = InkBlack
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    when {
                        weatherState.isLoading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = InkBlack)
                            }
                        }

                        weatherState.errorMessage != null -> {
                            Text(
                                text = weatherState.errorMessage ?: "Lỗi kết nối",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TodayRed
                            )
                        }

                        else -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${weatherState.temperature}°",
                                        fontSize = 54.sp,
                                        fontWeight = FontWeight.Black,
                                        color = InkBlack
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = weatherState.conditionText,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = InkBlack
                                        )
                                        Text(
                                            text = "Cao ${weatherState.todayHigh}°  •  Thấp ${weatherState.todayLow}°",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = InkBlack
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = weatherIconForCode(weatherState.weatherCode),
                                    contentDescription = null,
                                    tint = InkBlack,
                                    modifier = Modifier.size(44.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                MetricPill(
                                    modifier = Modifier.weight(1f),
                                    label = "Mây che phủ",
                                    value = "${weatherState.cloudCover}%"
                                )
                                MetricPill(
                                    modifier = Modifier.weight(1f),
                                    label = "Độ ẩm",
                                    value = "${weatherState.humidity}%"
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))
                            HorizontalDivider(color = BorderCream, thickness = 1.dp)
                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Dự báo 3 ngày tới",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkBlack
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            weatherState.forecast3Days.forEachIndexed { idx, day ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.3f)) {
                                        Text(
                                            text = day.dateLabel,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = InkBlack
                                        )
                                        Text(
                                            text = day.description,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = InkMuted
                                        )
                                    }

                                    Icon(
                                        imageVector = weatherIconForCode(day.weatherCode),
                                        contentDescription = null,
                                        tint = InkBlack,
                                        modifier = Modifier.size(22.dp)
                                    )

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Text(
                                        text = "${day.maxTemp}° / ${day.minTemp}°",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = InkBlack,
                                        textAlign = TextAlign.End
                                    )
                                }

                                if (idx < weatherState.forecast3Days.lastIndex) {
                                    HorizontalDivider(color = BorderCream, thickness = 0.8.dp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricPill(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(CreamSoftPill)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = InkMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = InkBlack
        )
    }
}

private fun getGreetingByHour(hour: Int): String = when (hour) {
    in 5..10 -> "Chào buổi sáng"
    in 11..12 -> "Chào buổi trưa"
    in 13..17 -> "Chào buổi chiều"
    else -> "Chào buổi tối"
}

private fun formatVietnameseFullDate(date: LocalDate): String {
    val weekday = when (date.dayOfWeek.value) {
        1 -> "Thứ Hai"
        2 -> "Thứ Ba"
        3 -> "Thứ Tư"
        4 -> "Thứ Năm"
        5 -> "Thứ Sáu"
        6 -> "Thứ Bảy"
        else -> "Chủ Nhật"
    }
    return "$weekday, ${date.dayOfMonth}/${date.monthValue}/${date.year}"
}

private fun weatherIconForCode(code: Int): ImageVector = when (code) {
    0, 1 -> Icons.Outlined.WbSunny
    2, 3, 45, 48 -> Icons.Outlined.Cloud
    51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> Icons.Outlined.Grain
    95, 96, 99 -> Icons.Outlined.Thunderstorm
    else -> Icons.Outlined.Cloud
}
