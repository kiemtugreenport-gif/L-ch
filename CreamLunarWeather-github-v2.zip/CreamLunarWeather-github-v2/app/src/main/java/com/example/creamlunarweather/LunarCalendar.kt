package com.example.creamlunarweather

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.floor

data class LunarDateInfo(
    val day: Int,
    val month: Int,
    val year: Int,
    val isLeapMonth: Boolean,
    val yearCanChi: String
) {
    fun shortDayLabel(): String = "$day/$month"

    fun pillLabel(): String {
        val leapMark = if (isLeapMonth) "+" else ""
        val dd = day.toString().padStart(2, '0')
        val mm = month.toString().padStart(2, '0')
        return "$dd/$mm$leapMark ÂL • $yearCanChi"
    }
}

data class WeekDayItem(
    val date: LocalDate,
    val shortWeekday: String,
    val solarDay: Int,
    val lunarShort: String,
    val isToday: Boolean
)

object LunarCalendar {
    private const val TIME_ZONE = 7.0

    private val CAN = arrayOf(
        "Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"
    )
    private val CHI = arrayOf(
        "Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"
    )

    fun getLunarDate(date: LocalDate): LunarDateInfo {
        val jd = jdnFromDate(date.dayOfMonth, date.monthValue, date.year)
        val k = floor((jd - 2415021.076998695) / 29.530588853).toInt()
        var monthStart = getNewMoonDay(k + 1, TIME_ZONE)
        if (monthStart > jd) {
            monthStart = getNewMoonDay(k, TIME_ZONE)
        }
        var a11 = getLunarMonth11(date.year, TIME_ZONE)
        var b11 = a11
        val lunarYear: Int
        if (a11 >= monthStart) {
            lunarYear = date.year
            a11 = getLunarMonth11(date.year - 1, TIME_ZONE)
        } else {
            lunarYear = date.year + 1
            b11 = getLunarMonth11(date.year + 1, TIME_ZONE)
        }
        val lunarDay = jd - monthStart + 1
        val diff = floor((monthStart - a11) / 29.0).toInt()
        var lunarLeap = false
        var lunarMonth = diff + 11
        if (b11 - a11 > 365) {
            val leapMonthDiff = getLeapMonthOffset(a11, TIME_ZONE)
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10
                if (diff == leapMonthDiff) {
                    lunarLeap = true
                }
            }
        }
        if (lunarMonth > 12) {
            lunarMonth -= 12
        }
        if (lunarMonth >= 11 && diff < 4) {
            lunarYear - 1
        }

        val canChiYear = "${CAN[(lunarYear + 6) % 10]} ${CHI[(lunarYear + 8) % 12]}"
        return LunarDateInfo(
            day = lunarDay,
            month = lunarMonth,
            year = lunarYear,
            isLeapMonth = lunarLeap,
            yearCanChi = canChiYear
        )
    }

    fun getWeekStrip(referenceDate: LocalDate = LocalDate.now()): List<WeekDayItem> {
        val monday = referenceDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val labels = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
        return (0..6).map { offset ->
            val d = monday.plusDays(offset.toLong())
            val lunar = getLunarDate(d)
            WeekDayItem(
                date = d,
                shortWeekday = labels[offset],
                solarDay = d.dayOfMonth,
                lunarShort = lunar.shortDayLabel(),
                isToday = d == referenceDate
            )
        }
    }

    private fun jdnFromDate(dd: Int, mm: Int, yy: Int): Int {
        val a = (14 - mm) / 12
        val y = yy + 4800 - a
        val m = mm + 12 * a - 3
        var jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
        if (jd < 2299161) {
            jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083
        }
        return jd
    }

    private fun getNewMoonDay(k: Int, timeZone: Double): Int {
        val t = k / 1236.85
        val t2 = t * t
        val t3 = t2 * t
        val dr = Math.PI / 180.0
        var jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3
        jd1 += 0.00033 * Math.sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)
        val m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3
        val mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3
        val f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3
        var c1 = (0.1734 - 0.000393 * t) * Math.sin(m * dr) + 0.0021 * Math.sin(2 * m * dr)
        c1 = c1 - 0.4068 * Math.sin(mpr * dr) + 0.0161 * Math.sin(2 * mpr * dr)
        c1 = c1 - 0.0004 * Math.sin(3 * mpr * dr)
        c1 = c1 + 0.0104 * Math.sin(2 * f * dr) - 0.0051 * Math.sin((m + mpr) * dr)
        c1 = c1 - 0.0074 * Math.sin((m - mpr) * dr) + 0.0004 * Math.sin((2 * f + m) * dr)
        c1 = c1 - 0.0004 * Math.sin((2 * f - m) * dr) - 0.0006 * Math.sin((2 * f + mpr) * dr)
        c1 = c1 + 0.0010 * Math.sin((2 * f - mpr) * dr) + 0.0005 * Math.sin((mpr + 2 * m) * dr)
        val deltat = if (t < -11) {
            0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t3 * t
        } else {
            -0.000278 + 0.000265 * t + 0.000262 * t2
        }
        val jdNew = jd1 + c1 - deltat
        return floor(jdNew + 0.5 + timeZone / 24.0).toInt()
    }

    private fun getSunLongitude(jdn: Int, timeZone: Double): Int {
        val t = (jdn - 0.5 - timeZone / 24.0 - 2451545.0) / 36525.0
        val t2 = t * t
        val dr = Math.PI / 180.0
        val m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
        val l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
        var dl = (1.91460 - 0.004817 * t - 0.000014 * t2) * Math.sin(m * dr)
        dl += (0.019993 - 0.000101 * t) * Math.sin(2 * m * dr) + 0.000290 * Math.sin(3 * m * dr)
        var l = l0 + dl
        l *= dr
        l -= Math.PI * 2 * floor(l / (Math.PI * 2))
        return floor(l / Math.PI * 6).toInt()
    }

    private fun getLunarMonth11(yy: Int, timeZone: Double): Int {
        val off = jdnFromDate(31, 12, yy) - 2415021
        val k = floor(off / 29.530588853).toInt()
        var nm = getNewMoonDay(k, timeZone)
        val sunLong = getSunLongitude(nm, timeZone)
        if (sunLong >= 9) {
            nm = getNewMoonDay(k - 1, timeZone)
        }
        return nm
    }

    private fun getLeapMonthOffset(a11: Int, timeZone: Double): Int {
        val k = floor((a11 - 2415021.076998695) / 29.530588853 + 0.5).toInt()
        var last = 0
        var i = 1
        var arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
        do {
            last = arc
            i++
            arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
        } while (arc != last && i < 14)
        return i - 1
    }
}
