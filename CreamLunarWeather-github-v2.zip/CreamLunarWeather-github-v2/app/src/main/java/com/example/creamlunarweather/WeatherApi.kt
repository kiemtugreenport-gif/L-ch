package com.example.creamlunarweather

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

data class DailyForecast(
    val dateLabel: String,
    val weatherCode: Int,
    val description: String,
    val maxTemp: Int,
    val minTemp: Int
)

data class WeatherUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val temperature: Int = 0,
    val cloudCover: Int = 0,
    val humidity: Int = 0,
    val todayHigh: Int = 0,
    val todayLow: Int = 0,
    val conditionText: String = "Đang tải...",
    val weatherCode: Int = 0,
    val forecast3Days: List<DailyForecast> = emptyList()
)

object WeatherApi {
    suspend fun fetchWeather(lat: Double, lon: Double): Result<WeatherUiState> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,cloud_cover,weather_code" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                    "&timezone=Asia%2FBangkok&forecast_days=4"

                val responseText = URL(url).readText()
                val root = JSONObject(responseText)

                val current = root.getJSONObject("current")
                val temp = Math.round(current.getDouble("temperature_2m")).toInt()
                val humidity = Math.round(current.getDouble("relative_humidity_2m")).toInt()
                val cloud = Math.round(current.getDouble("cloud_cover")).toInt()
                val currentCode = current.getInt("weather_code")

                val daily = root.getJSONObject("daily")
                val dates = daily.getJSONArray("time")
                val codes = daily.getJSONArray("weather_code")
                val maxTemps = daily.getJSONArray("temperature_2m_max")
                val minTemps = daily.getJSONArray("temperature_2m_min")

                val todayHigh = Math.round(maxTemps.getDouble(0)).toInt()
                val todayLow = Math.round(minTemps.getDouble(0)).toInt()

                val viLocale = Locale("vi", "VN")
                val next3Days = (1..3).map { idx ->
                    val isoDate = LocalDate.parse(dates.getString(idx))
                    val wd = isoDate.dayOfWeek.getDisplayName(TextStyle.SHORT, viLocale)
                        .replaceFirstChar { it.uppercase() }
                    val dm = "${isoDate.dayOfMonth}/${isoDate.monthValue}"
                    val code = codes.getInt(idx)
                    DailyForecast(
                        dateLabel = "$wd • $dm",
                        weatherCode = code,
                        description = mapWeatherCode(code),
                        maxTemp = Math.round(maxTemps.getDouble(idx)).toInt(),
                        minTemp = Math.round(minTemps.getDouble(idx)).toInt()
                    )
                }

                Result.success(
                    WeatherUiState(
                        isLoading = false,
                        errorMessage = null,
                        temperature = temp,
                        cloudCover = cloud,
                        humidity = humidity,
                        todayHigh = todayHigh,
                        todayLow = todayLow,
                        conditionText = mapWeatherCode(currentCode),
                        weatherCode = currentCode,
                        forecast3Days = next3Days
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun mapWeatherCode(code: Int): String = when (code) {
        0 -> "Trời quang"
        1 -> "Ít mây"
        2 -> "Mây rải rác"
        3 -> "Nhiều mây"
        45, 48 -> "Có sương mù"
        51, 53, 55 -> "Mưa phùn"
        56, 57 -> "Mưa phùn lạnh"
        61, 63, 65 -> "Có mưa"
        66, 67 -> "Mưa lạnh"
        71, 73, 75, 77 -> "Tuyết rơi"
        80, 81, 82 -> "Mưa rào"
        85, 86 -> "Mưa tuyết"
        95 -> "Dông"
        96, 99 -> "Dông kèm mưa đá"
        else -> "Thời tiết ổn định"
    }
}
