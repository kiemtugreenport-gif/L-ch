# CreamLunarWeather

Ứng dụng Android (Kotlin + Jetpack Compose) hiển thị đồng hồ lớn, lời chào theo buổi, lịch âm Việt Nam + Can Chi, dải 7 ngày T2–CN và thời tiết từ Open-Meteo.

## Cách build APK tự động trên GitHub
1. Giải nén file zip và đưa toàn bộ nội dung bên trong lên nhánh `main` của repository GitHub.
2. Vào tab **Actions** → chọn workflow **Build Android APK**.
3. Sau khi chạy xong, tải file APK ở mục **Artifacts** (`app-debug-apk`).
